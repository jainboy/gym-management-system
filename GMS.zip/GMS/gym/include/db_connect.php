<?php
include_once 'psl-config.php';   // As functions.php is not included
$mysqli = new mysqli("localhost", "root", "", "table");
?>
